create function log10(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function log10(numeric) owner to postgres;

