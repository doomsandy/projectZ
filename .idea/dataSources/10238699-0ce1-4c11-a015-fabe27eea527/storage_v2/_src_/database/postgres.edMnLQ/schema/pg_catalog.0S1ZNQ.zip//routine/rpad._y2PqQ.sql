create function rpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function rpad(text, integer) owner to postgres;

