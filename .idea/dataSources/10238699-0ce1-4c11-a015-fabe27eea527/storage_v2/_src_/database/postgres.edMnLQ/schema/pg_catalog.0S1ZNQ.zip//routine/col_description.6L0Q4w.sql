create function col_description(oid, integer) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function col_description(oid, integer) owner to postgres;

